import 'package:flutter/material.dart';
import 'post_bloc.dart';

class PostProvider extends InheritedWidget{
  PostProvider({super.key, required super.child});

  final PostBloc postBloc = PostBloc();

  static PostBloc of(BuildContext context){
    return (context.dependOnInheritedWidgetOfExactType<PostProvider>() as PostProvider).postBloc;
  }

  @override
  bool updateShouldNotify(covariant InheritedWidget oldWidget) {
    // TODO: implement updateShouldNotify
    return true;
  }
}