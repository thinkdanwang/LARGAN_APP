import 'package:dio/dio.dart';

import '../http/core/hi_net.dart';
import '../http/request/test_request.dart';

class PostBloc {
  final Dio dio = Dio();
  Future<Response> getSettingsData() async {
    Response res = await dio.get(
        'http://eleave.largan.com.tw/msserver/program/getSetting.php?user_uid=1141261');
    try {
      if (res.statusCode == 200 && res.data != null) {
        return res;
      }
    } on DioException catch (e) {
      print('dio error $e');
    } catch (e) {
      print('other error $e');
    }
    return res;
  }

  Future<void> test() async {
    TestRequest request = TestRequest();
    request.add("add", "ddd");
    request.addHeader("add", "ddd");
    var res = await HiNet.getInstance()?.fire(request);
    print(res);
    return res;
  }
}
