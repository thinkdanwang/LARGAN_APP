import 'package:dio/dio.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:largan/models/login_user.dart';
import 'package:dio/dio.dart';

class AuthService{

  final _auth = FirebaseAuth.instance;
  ///把firebase物件轉成LoginUser
  LoginUser? _userFromFirebasedUser(User user){
    return user != null ? LoginUser(uid: user.uid):null;
  }
  ///當登入狀態變動時Stream
  // Stream<LoginUser> get user{
  //   return _auth.userChanges().map(_userFromFirebasedUser);
  // }
  ///使用firebase email+password 進行登入
  Future signInWithNameAndPassword(String email,String password) async {
    try {
      var result = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      return result.user;
    } catch (error){
      print(error.toString());
      return null;
    }
  }
  Future signInAnonymously(String email,String password) async {
    try {
      var result1 = await _auth.signInAnonymously();
      return result1.user;
    } catch (error){
      print(error.toString());
      return null;
    }
  }

  ///使用firebase name+password 進行註冊
  Future registerWithNameAndPassword(String email,String password) async {
    try {
      var result = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      return result.user;
    } catch (error){
      print(error.toString());
      return null;
    }
  }
  ///登出
  Future signOut() async {
    try {
      return await _auth.signOut();
    } catch (error) {
      print(error.toString());
      return null;
    }
  }
  ///使用msserver 進行驗證
  Future<Response> signInWithMsServer(String name,String password) async {
    final Dio dio = Dio();
    Response res = await dio.get(
        'http://eleave.largan.com.tw/msserver/program/checkAccount_for_app.php?user_uid=$name&password=$password');
    try {
      if (res.statusCode == 200 && res.data != null) {
        return res;
      }
    } on DioException catch (e) {
      print('dio error $e');
    } catch (e) {
      print('other error $e');
    }
    return res;
  }
  ///進行登入後資料庫新增
}