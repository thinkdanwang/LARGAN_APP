import 'dart:core';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

class LoadModuleJson{
  static const String jsonModuleData = 'assets/json/modules.json';

  static Future<dynamic> loadJson(String jsonFile) async{
    String data = await rootBundle.loadString(jsonFile);
    var jsonObject = json.decode(data);
    return jsonObject;
  }
}