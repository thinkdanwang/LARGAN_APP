class LoginUser{
  final String uid;
  LoginUser({required this.uid});
}