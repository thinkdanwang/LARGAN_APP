/// user_uid : "3970801"
/// user_name : "李敏哲"
/// user_email : "majorli@largan.com.tw"
/// orglevel_name : "資安長"
/// orglevel_value : "6000"

class SignSetting {
  SignSetting({
    String? userUid,
    String? userName,
    String? userEmail,
    String? orglevelName,
    String? orglevelValue,
  }) {
    _userUid = userUid;
    _userName = userName;
    _userEmail = userEmail;
    _orglevelName = orglevelName;
    _orglevelValue = orglevelValue;
  }

  SignSetting.fromJson(dynamic json) {
    _userUid = json['user_uid'];
    _userName = json['user_name'];
    _userEmail = json['user_email'];
    _orglevelName = json['orglevel_name'];
    _orglevelValue = json['orglevel_value'];
  }

  String? _userUid;
  String? _userName;
  String? _userEmail;
  String? _orglevelName;
  String? _orglevelValue;

  SignSetting copyWith({
    String? userUid,
    String? userName,
    String? userEmail,
    String? orglevelName,
    String? orglevelValue,
  }) =>
      SignSetting(
        userUid: userUid ?? _userUid,
        userName: userName ?? _userName,
        userEmail: userEmail ?? _userEmail,
        orglevelName: orglevelName ?? _orglevelName,
        orglevelValue: orglevelValue ?? _orglevelValue,
      );

  String? get userUid => _userUid;

  String? get userName => _userName;

  String? get userEmail => _userEmail;

  String? get orglevelName => _orglevelName;

  String? get orglevelValue => _orglevelValue;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['user_uid'] = _userUid;
    map['user_name'] = _userName;
    map['user_email'] = _userEmail;
    map['orglevel_name'] = _orglevelName;
    map['orglevel_value'] = _orglevelValue;
    return map;
  }
}
