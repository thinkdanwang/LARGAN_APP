import 'dart:core';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

class LoadJson{
  static const String jsonHomePageData = 'assets/json/home_page.json';

  static Future<dynamic> loadJson(String jsonFile) async{
    String data = await rootBundle.loadString(jsonFile);
    var jsonObject = json.decode(data);
    return jsonObject;
  }
}