import 'package:largan/http/core/hi_net_adapter.dart';
import 'package:largan/http/request/base_request.dart';

/// 測試adapter轉接器 mock資料
class MockAdapter extends HiNetAdapter {
  @override
  Future<HiNetResponse<T>> send<T>(BaseRequest request) {
    // TODO: implement send
    throw UnimplementedError();
  }
  // @override
  // Future<HiNetResponse<T>> send<T>(BaseRequest request) {
  //   return Future<HiNetResponse>.delayed(
  //       const Duration(milliseconds: 1000),
  //       () => HiNetResponse(
  //           data: {"code": 0, "message": "success"}, statusCode: 200));
  // }
}
