import 'dart:convert';

import 'package:largan/http/request/base_request.dart';

/// 網路請求抽象類別
abstract class HiNetAdapter {
  Future<HiNetResponse<T>> send<T>(BaseRequest request);
}

/// 統一網路層返回格式 泛型 增加靈活度
class HiNetResponse<T> {
  HiNetResponse(
      {required this.data,
      required this.request,
      required this.statusCode,
      required this.statusMessage,
      this.extra});

  final T data;
  final BaseRequest request;
  final int statusCode;
  final String statusMessage;
  final dynamic extra;

  @override
  String toString() {
    if (data is Map) {
      return json.encode(data);
    }
    return data.toString();
  }
}
