import 'package:bloc_pattern/bloc_pattern.dart';
import "package:firebase_core/firebase_core.dart";
import "package:firebase_messaging/firebase_messaging.dart";
import "package:flutter/material.dart";
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import "package:hive_flutter/adapters.dart";
import 'package:hive_flutter/hive_flutter.dart';
import 'package:largan/bloc/post_provider.dart';
import "package:largan/pages/home.dart";
import 'package:largan/screens/authenticate/login.dart';
import 'package:largan/screens/user_info/attendance_page.dart';
import "package:largan/screens/user_info/extrawork_page.dart";
import "package:largan/screens/user_info/user_info_screen.dart";

import 'screens/authenticate/login_bloc.dart';
import 'services/local_notification_service.dart';

/// flutterLocalNotificationsPlugin 初始設定
const AndroidNotificationChannel channel = AndroidNotificationChannel(
  'high_importance_channel', // id
  'High Importance Notifications', // title
  importance: Importance.max,
);

/// flutterLocalNotificationsPlugin 初始宣告
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(channel);

  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
    alert: true,
    badge: true,
    sound: true,
  );

  // Initialize hive
  await Hive.initFlutter();
  // Open the peopleBox
  await Hive.openBox('user_box');

  runApp(const MyApp());
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.
  await Firebase.initializeApp();
  print("Handling a background message ${message.messageId}");
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();

    /// 初始化 LocalNotification 設定
    LocalNotificationService.initialize(context);

    ///gives you the message on which user taps
    ///and it opened the app from terminated state
    /// App 被完全關掉後，時點選通知開啟App（Terminated）
    FirebaseMessaging.instance.getInitialMessage().then((message) {
      if (message != null) {
        // print('從 App 被完全關閉狀態打開：' + message.data["route"]);
        final routeFromMessage = message.data["route"];
        Navigator.pushNamed(context, routeFromMessage);
      }
    });

    /// 監聽 terminal 推播事件。
    FCMManager.foregroundMessage();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      blocs: [Bloc((i) => LoginBloc())],
      dependencies: const [],
      child: PostProvider(
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: "LARGAN APP",
          theme: ThemeData(),
          home: const LoginManagement(),
        ),
      ),
    );
  }
}

class LoginManagement extends StatefulWidget {
  const LoginManagement({super.key});

  @override
  State<LoginManagement> createState() => _LoginManagementState();
}

class _LoginManagementState extends State<LoginManagement> {
  bool showSignIn = true;

  @override
  Widget build(BuildContext context) {
    LoginBloc loginBloc = BlocProvider.getBloc<LoginBloc>();
    return StreamBuilder(
      stream: loginBloc.currentPageStream,
      builder: (context, snap) {
        return IndexedStack(
          index: loginBloc.currentPage,
          children: <Widget>[
            LoginPage(
              toggleView: toggleView,
            ),
            const MainPage(),
            const AttendancePage(),
            const UserInfoScreen(),
            const ExtraworkInfoPage(),
          ],
        );
      },
    );
  }

  void toggleView() {
    setState(() {
      showSignIn = !showSignIn;
    });
  }
}
