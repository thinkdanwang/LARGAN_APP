import 'package:bloc_pattern/bloc_pattern.dart';
import 'package:flutter/material.dart';

import '../authenticate/login_bloc.dart';

class ExtraworkInfoPage extends StatefulWidget {
  const ExtraworkInfoPage({super.key});

  @override
  State<ExtraworkInfoPage> createState() => _ExtraworkInfoPageState();
}

class _ExtraworkInfoPageState extends State<ExtraworkInfoPage> {
  late LoginBloc _loginBloc;

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    _loginBloc = BlocProvider.getBloc<LoginBloc>();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: ()=>{
            _loginBloc.currentPage = 1
          },
        ),
        title: const Text("加班單資訊"),
      ),
    );
  }
}
