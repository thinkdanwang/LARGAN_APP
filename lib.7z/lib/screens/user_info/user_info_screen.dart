import 'package:bloc_pattern/bloc_pattern.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../authenticate/login_bloc.dart';

class UserInfoScreen extends StatefulWidget {
  const UserInfoScreen({super.key});

  @override
  State<UserInfoScreen> createState() => _UserInfoScreenState();
}

class _UserInfoScreenState extends State<UserInfoScreen> {
  late LoginBloc _loginBloc;
  Map allData = {};
  final Dio dio = Dio();

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    _loginBloc = BlocProvider.getBloc<LoginBloc>();
  }
  getAccountData() async {
    Response res = await dio.get("http://eleave.largan.com.tw/msserver/program/ajax_select_user.php?user_uid=1141261");
    try {
      if (res.statusCode == 200 && res.data != null) {
        allData = res.data;
        print(res);
      }
      allData = {};
    } on DioException catch (e) {
      print('dio error $e');
    } catch (e) {
      print('other error $e');
    }
    if (mounted) {
      setState(() {});
    }
  }

  // @override
  // void initState() {
  //   print('initState');
  //   super.initState();
  //
  //   getAccountData();
  // }
  //
  // @override
  // void dispose() {
  //   // TODO: implement dispose
  //   allData = {};
  //   super.dispose();
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
          appBar: AppBar(
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios),
              onPressed: ()=>{
                _loginBloc.currentPage = 1
              },
            ),
            title: const Text("個人基本資料"),
          ),
          body: const Column(children: <Widget>[Text("帳號Account:")],),
        );
  }
}
