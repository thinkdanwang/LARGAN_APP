import 'package:bloc_pattern/bloc_pattern.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:largan/services/auth.dart';

import '../../shared/constants.dart';
import 'login_bloc.dart';

class LoginPage extends StatefulWidget {
  // const LoginPage({super.key});

  final Function toggleView;

  const LoginPage({super.key, required this.toggleView});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _nameController = TextEditingController();
  final _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final AuthService _auth = AuthService();
  late LoginBloc _loginBloc;
  String name = '';
  String password = '';
  String errorMessage = '';
  dynamic result = '';
  List<String> list = <String>['LARGAN員工', '供應商'];
  String? selectedValue;
  late bool _rememberAccount;

  final List<String> items = ['LARGAN員工', '供應商'];

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    _loginBloc = BlocProvider.getBloc<LoginBloc>();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.all(Radius.circular(15)),
        ),
        child: Form(
          key: _formKey,
          child: ListView(
            children: <Widget>[
              _buildCompanyTitle(),
              _buildTitle(),
              DropdownButtonFormField2<String>(
                isExpanded: true,
                decoration: InputDecoration(
                  // Add Horizontal padding using menuItemStyleData.padding so it matches
                  // the menu padding when button's width is not specified.
                  contentPadding: const EdgeInsets.symmetric(vertical: 16),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  // Add more decoration..
                ),
                hint: const Text(
                  '請選擇身份別',
                  style: TextStyle(fontSize: 14),
                ),
                items: items
                    .map((item) => DropdownMenuItem<String>(
                          value: item,
                          child: Text(
                            item,
                            style: const TextStyle(
                              fontSize: 14,
                            ),
                          ),
                        ))
                    .toList(),
                validator: (value) {
                  if (value == null) {
                    return '請選擇身份別!';
                  }
                  return null;
                },
                onChanged: (value) {
                  //Do something when selected item is changed.
                  selectedValue = value.toString();
                },
                onSaved: (value) {
                  selectedValue = value.toString();
                },
                buttonStyleData: const ButtonStyleData(
                  padding: EdgeInsets.only(right: 8),
                ),
                iconStyleData: const IconStyleData(
                  icon: Icon(
                    Icons.arrow_drop_down,
                    color: Colors.black45,
                  ),
                  iconSize: 24,
                ),
                dropdownStyleData: DropdownStyleData(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                menuItemStyleData: const MenuItemStyleData(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 24.0, vertical: 16.0),
                child: TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) return '請輸入帳號!';
                    // if (!isWordAndDigit(value)) return '請輸入文字or數字!';
                    return null;
                  },
                  controller: _nameController,
                  decoration: textInputDecoration.copyWith(
                    labelText: "Account ID *",
                    hintText: "Enter Your Largan Account ID",
                  ),
                  onChanged: (value) {
                    setState(() {
                      name = value;
                    });
                  },
                  // onFieldSubmitted: (value) {
                  //   print('onFieldSubmitted:$value');
                  // },
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 24.0, vertical: 16.0),
                child: TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) return '請輸入密碼!';
                  },
                  obscureText: true,
                  controller: _passwordController,
                  decoration: textInputDecoration.copyWith(
                    labelText: "Password *",
                    hintText: "Enter Your password",
                  ),
                  onChanged: (value) {
                    setState(() {
                      password = value;
                    });
                  },
                ),
              ),
              const SizedBox(
                height: 52.0,
              ),
              SizedBox(
                width: size.width - 100.0,
                height: 48.0,
                child: ElevatedButton(
                  child: const Text("Login"),
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      switch (selectedValue) {
                        case 'LARGAN員工':
                          dynamic result =
                              await _auth.signInWithMsServer(name, password);
                          if (result.data == 'Array') {
                            errorMessage = '登入失敗';
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text("$errorMessage")),
                            );
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('登入成功!')),
                            );
                            errorMessage = '';
                            _loginBloc.currentPage = 1;
                            // Navigator.pushReplacementNamed(context, "/home");
                          }
                          break;
                        case '供應商':
                          dynamic result = await _auth
                              .signInWithNameAndPassword(name, password);
                          print(result);
                          if (result == null) {
                            errorMessage = '登入失敗';
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text("$errorMessage")),
                            );
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('登入成功!')),
                            );
                            errorMessage = '';
                            _loginBloc.currentPage = 1;
                            // Navigator.pushReplacementNamed(context, "/home");
                          }
                          break;
                      }
                    }
                  },
                ),
              ),
              // Text("$errorMessage",style: const TextStyle(color: Colors.red),),
              Container(
                  alignment: Alignment.center,
                  child: Flex(
                    direction: Axis.vertical,
                    children: <Widget>[
                      const Text(
                        "Join us 加入我們 ?",
                        textAlign: TextAlign.center,
                        softWrap: true,
                      ),
                      TextButton(
                        onPressed: () => widget.toggleView(),
                        child: const Text(
                          "Sign up",
                          style: TextStyle(color: Colors.blue),
                        ),
                      ),
                    ],
                  )),
            ],
          ),
        ),
      ),
    );
  }

  bool isWordAndDigit(String value) {
    return RegExp(r"^[ZA-ZZa-z0-9_]+$").hasMatch(value);
  }

  /// 私有方法
  Widget _buildTitle() {
    return Container(
        child: const Flex(
      direction: Axis.vertical,
      children: <Widget>[
        Text(
          '請選擇您的身份別，再輸入您的帳號與密碼',
          textAlign: TextAlign.center,
          softWrap: true,
          style: TextStyle(fontFamily: 'Monoton'),
        ),
      ],
    ));
  }

  Widget _buildCompanyTitle() {
    return Container(
      height: 100,
      width: 100,
      margin: const EdgeInsets.only(top: 100.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(40),
        image: const DecorationImage(
          image: AssetImage(
            'assets/images/LARGAN_logo.png',
          ),
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}

class LoginSetData extends ChangeNotifier {
  String _category; //身分類別
  String _name; //帳號
  String _password; //密碼

  get category => _category;
  get name => _name;
  get password => _password;
  LoginSetData(this._category, this._name, this._password);
  setData() {
    _category = _category;
    _name = _name;
    _password = _password;
  }
}
