import 'package:bloc_pattern/bloc_pattern.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:largan/pages/home.dart';
import 'package:flutter_progress_hud/flutter_progress_hud.dart';
import 'package:largan/services/auth.dart';

import '../../shared/constants.dart';
import 'login_bloc.dart';

class Register extends StatefulWidget {
  // const LoginPage({super.key});

  final Function toggleView;

  const Register({super.key, required this.toggleView});

  @override
  State<Register> createState() => _LoginPageState();
}

class _LoginPageState extends State<Register> {
  final _nameController = TextEditingController();
  final _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final AuthService _auth = AuthService();
  late LoginBloc _loginBloc;
  String name = '';
  String password = '';
  String company = '';
  String errorMessage = '';

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    _loginBloc = BlocProvider.getBloc<LoginBloc>();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        body: Center(
          child: Container(
            decoration: const BoxDecoration(
              //     gradient: LinearGradient(
              //   begin: Alignment.topRight,
              //   end: Alignment.bottomLeft,
              //   colors: [Colors.orange, Colors.grey],
              // ),
              image: DecorationImage(
                image: AssetImage("assets/images/back_image.jpg"),
                fit: BoxFit.cover,
              ),
            ),
            child: Form(
              key: _formKey,
              child: ListView(
                children: <Widget>[
                  _buildCompanyTitle(),
                  _buildTitle(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24.0, vertical: 16.0),
                    child: TextFormField(
                      validator: (value) {
                        if (value == null || value.isEmpty) return '請輸入內容!';
                        // if (!isWordAndDigit(value)) return '請輸入文字or數字!';
                        return null;
                      },
                      controller: _nameController,
                      decoration: textInputDecoration.copyWith(
                        labelText: "Email *",
                        hintText: "Enter Your Email",
                      ),
                      onChanged: (value) {
                        setState(() {
                          name = value;
                        });
                      },
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24.0, vertical: 16.0),
                    child: TextFormField(
                      validator: (value) {
                        if (value == null || value.isEmpty) return '請輸入密碼!';
                      },
                      obscureText: true,
                      controller: _passwordController,
                      decoration: textInputDecoration.copyWith(
                        labelText: "Password *",
                        hintText: "Enter Your password",
                      ),
                      onChanged: (value) {
                        setState(() {
                          password = value;
                        });
                      },
                    ),
                  ),
                  const SizedBox( height: 13.0,),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24.0, vertical: 16.0),
                    child: TextFormField(
                      validator: (value) {
                        if (value == null || value.isEmpty) return '請輸入公司名稱!';
                      },
                      obscureText: true,
                      controller: _passwordController,
                      decoration: textInputDecoration.copyWith(
                        labelText: "Company Name *",
                        hintText: "Enter Your Company",
                      ),
                      onChanged: (value) {
                        setState(() {
                          company = value;
                        });
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 52.0,
                  ),
                  SizedBox(
                    width: size.width - 100.0,
                    height: 48.0,
                    child: ElevatedButton(
                      child: const Text("註冊"),
                      onPressed: () async {
                        if (_formKey.currentState!.validate()) {
                          dynamic result = await _auth.registerWithNameAndPassword(name, password);
                          print(result);
                          if (result == null){
                            var errorMessage = '登入失敗';
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('登入成功!')),
                            );
                            _loginBloc.currentPage = 1;
                            // Navigator.pushReplacementNamed(context, "/home");
                          }
                        }
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 13.0,
                  ),
                  Text(errorMessage,style: const TextStyle(color: Colors.red),),
                ],
              ),
            ),
          ),
        ));
  }

  bool isWordAndDigit(String value) {
    return RegExp(r"^[ZA-ZZa-z0-9_]+$").hasMatch(value);
  }

  /// 私有方法
  Widget _buildTitle() {
    return Container(
        child: const Flex(
          direction: Axis.vertical,
          children: <Widget>[
            Text(
              '請輸入您的員工工號與密碼',
              textAlign: TextAlign.center,
              softWrap: true,
              style: TextStyle(fontFamily: 'Monoton'),
            ),
          ],
        ));
  }

  Widget _buildCompanyTitle() {
    return Container(
      margin: const EdgeInsets.only(top: 200.0, left: 20.0),
      child: Column(
        children: <Widget>[
          const Text(
            "LARGAN",
            style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.blue,
                fontSize: 60.0),
          ),
          Image.asset("assets/images/LARGAN_logo1.jpg"),

        ],
      ),
    );
  }
}

class VerticalChineseText extends StatelessWidget {
  const VerticalChineseText(
      {super.key, required this.textStyle, required this.text})
      : assert(text != null),
        assert(textStyle != null);

  final TextStyle textStyle;
  final String text;

  @override
  Widget build(BuildContext context) {
    List<Text> textList = text
        .split('')
        .map((e) => Text(
      e,
      style: textStyle,
    ))
        .toList();
    return Wrap(
      direction: Axis.vertical,
      children: textList,
    );
  }
}
