// import 'package:flutter/material.dart';
// import 'package:largan/pages/home_page.dart';
// import 'package:largan/screens/authenticate/authenticate.dart';

// import '../widgets/login_user_binder.dart';

// class Wrapper extends StatelessWidget {
//   const Wrapper({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return StreamBuilder(builder: (context, snap){
//       stream:LoginUserBinder.of(contex).value,
//       builder : (context ,snap){
//         if(!snap.hashData){
//               return const Authenticate();
//         } else {
//               return const HomePage();
//         }
//       }

//     });
//   }
// }
