import 'package:flutter/material.dart';

const InputDecoration textInputDecoration =
InputDecoration(
  prefixIcon: Icon(Icons.person),

  hintStyle: TextStyle(color: Colors.red),
  filled: true,
  fillColor: Colors.white30,
  contentPadding: EdgeInsets.all(12.0),
  enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white,width: 2.0)),
  focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey,width: 2.0)),
);