import 'dart:convert';

import 'package:bloc_pattern/bloc_pattern.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:largan/bloc/post_bloc.dart';
import 'package:largan/bloc/post_provider.dart';

import '../models/load_module_json.dart';
import '../screens/authenticate/login_bloc.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final int bgColor = 0xff1a1a;
  final int textGrayColor = 0xffafafaf;
  final int textRedColor = 0xffd40007;
  final Dio dio = Dio();
  Map allData = {};
  Map<String, dynamic>? modules;
  PostBloc? _postBloc;

  @override
  void dispose() {
    // TODO: implement dispose
    allData = {};
    // homePageDataSubject.close();

    super.dispose();
  }

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    _postBloc = PostProvider.of(context);
    LoadModuleJson.loadJson(LoadModuleJson.jsonModuleData).then(
      // (value) => print('jsonModuleData: $value'),
      (value) {
        print('jsonModuleData: $value');
        modules = value;
        print(modules?['info'][0]['tabs_name']);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    LoginBloc loginBloc = BlocProvider.getBloc<LoginBloc>();
    dynamic carouselListName = <String>['出勤資訊', '加班資訊', '福利津貼'];
    dynamic carouselListBloc = <int>[2, 4, 5];

    return Scaffold(
      backgroundColor: const Color.fromRGBO(217, 150, 57, 0.2),
      body: SafeArea(
          child: Column(
        children: <Widget>[
          const SizedBox(height: 1.0),
          CarouselSlider(
            options: CarouselOptions(
              height: 100.0,
              enableInfiniteScroll: false,
            ),
            items: [1, 2, 3].map((i) {
              return Builder(
                builder: (BuildContext context) {
                  int x = i - 1;
                  return GestureDetector(
                    onTap: () {
                      // print($modules['info'][x]['modules_name']);
                      loginBloc.currentPage = carouselListBloc[x];
                    },
                    child: Container(
                        width: size.width,
                        margin: const EdgeInsets.symmetric(horizontal: 5.0),
                        decoration: BoxDecoration(
                            color: const Color.fromRGBO(0, 49, 83, 0.9),
                            border: Border.all(
                              width: 2.0,
                              color: const Color.fromRGBO(162, 126, 126, 1),
                            ),
                            borderRadius:
                                const BorderRadius.all(Radius.circular(10))),
                        child: SizedBox(
                          child: Row(
                            children: <Widget>[
                              Text(
                                carouselListName[x],
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 22.0,
                                ),
                              )
                            ],
                          ),
                        )),
                  );
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 1.0),
          SizedBox(
            child: Column(
              children: <Widget>[
                Row(
                  // children: List.generate(text.length,(index){
                  //   return Text(text[index].toString());
                  // }),

                  children: <Widget>[
                    Container(
                      width: (size.width - 8) / 4,
                      height: 100.0,
                      margin: const EdgeInsets.all(1),
                      padding: const EdgeInsets.only(top: 30.0),
                      decoration: BoxDecoration(
                        color: Colors.black26,
                        border: Border.all(width: 3.0, color: Colors.red),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(20)),
                      ),
                      child: Column(
                        children: <Widget>[
                          Icon(Icons.person),
                          Text("${modules?['modules'][0]['modules_name']}")
                        ],
                      ),
                    ),
                    Container(
                      width: (size.width - 8) / 4,
                      height: 100.0,
                      margin: const EdgeInsets.all(1),
                      decoration: const BoxDecoration(color: Colors.black26),
                      child: const Text("2"),
                    ),
                    Container(
                      width: (size.width - 8) / 4,
                      height: 100.0,
                      margin: const EdgeInsets.all(1),
                      decoration: const BoxDecoration(color: Colors.black26),
                      child: Text("3"),
                    ),
                    Container(
                      width: (size.width - 8) / 4,
                      height: 100.0,
                      margin: const EdgeInsets.all(1),
                      decoration: const BoxDecoration(color: Colors.black26),
                      child: Text("4"),
                    ),
                  ],
                ),
                Row(
                  children: <Widget>[
                    Container(
                      width: (size.width - 8) / 4,
                      height: 100.0,
                      margin: const EdgeInsets.all(1),
                      decoration: const BoxDecoration(color: Colors.black26),
                      child: Text("5"),
                    ),
                    Container(
                      width: (size.width - 8) / 4,
                      height: 100.0,
                      margin: const EdgeInsets.all(1),
                      decoration: const BoxDecoration(color: Colors.black26),
                      child: Text("6"),
                    ),
                    Container(
                      width: (size.width - 8) / 4,
                      height: 100.0,
                      margin: const EdgeInsets.all(1),
                      decoration: const BoxDecoration(color: Colors.black26),
                      child: Text("7"),
                    ),
                  ],
                )
              ],
            ),
          ),
          const SizedBox(height: 1.0),
          Expanded(
            child: FutureBuilder(
              future: _postBloc?.getSettingsData(),
              builder: (BuildContext context, AsyncSnapshot snap) {
                if (snap.hasData) {
                  Response res = snap.data;
                  return ListView.builder(
                      itemCount: json.decode(res.data).length,
                      // itemCount: res.data.length,
                      // itemCount: (res.data ?? []).length,
                      itemBuilder: (BuildContext context, int index) {
                        Map<String, dynamic> data =
                            json.decode(res.data)[index];
                        // Map<String, dynamic> data = res.data[index];
                        // print(index);
                        // print(json.decode(res.data)[index]);
                        // print(data);
                        // print(json.decode(res.data).length);
                        return InkWell(
                          child: ListTile(
                              title: Row(children: <Widget>[
                            Expanded(
                                child: Text(
                              '${data['user_name']}',
                              style: TextStyle(color: Color(textGrayColor)),
                            )),
                            Text(
                              '${data['user_email']}',
                              style: TextStyle(color: Color(textGrayColor)),
                            ),
                          ])),
                        );
                      });
                } else {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
              },
            ),
          ),
        ],
      )),
    );
  }
}

class GobalInfo extends StatelessWidget {
  const GobalInfo({super.key, required this.title, required this.page});

  final int textGrayColor = 0xffafafaf;
  final int textRedColor = 0xffd40007;
  final String title;
  final int page;

  @override
  Widget build(BuildContext context) {
    LoginBloc loginBloc = BlocProvider.getBloc<LoginBloc>();
    return InkWell(
      child: Row(
        children: <Widget>[
          const Icon(
            Icons.audiotrack,
            color: Colors.green,
          ),
          Column(
            children: <Widget>[
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6.0, vertical: 2.5),
                decoration: BoxDecoration(
                    color: Theme.of(context).canvasColor,
                    borderRadius: BorderRadius.circular(5.0)),
                child: Text(
                  '$title',
                  style: TextStyle(
                      color: Color(textGrayColor),
                      fontSize: 12.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Oswald'),
                ),
              ),
            ],
          ),
        ],
      ),
      onTap: () {
        loginBloc.currentPage = page;
      },
    );
  }
}
