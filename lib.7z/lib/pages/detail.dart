import 'package:flutter/material.dart';

class Detail extends StatelessWidget {
  const Detail(
      {super.key,
      required this.userUid,
      required this.userName,
      required this.userEmail,
      required this.orglevelName,
      required this.orglevelValue,});


  final String userUid;
  final String userName;
  final String userEmail;
  final String orglevelName;
  final String orglevelValue;
  final int textGrayColor = 0xffafafaf;
  final int textRedColor = 0xffd40007;

  Map<String, dynamic> toMap() => {
    'userUid': userUid,
    'userName': userName,
    'userEmail': userEmail,
    'orglevelName': orglevelName,
    'orglevelValue': orglevelValue,
  };
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    Map<String, dynamic> details = toMap();
    List<String> detailKeys = details.keys.toList();

    return Material(
      child: Container(
        //外框大小
        width: size.width * 0.8,
        height: 300.0,
        decoration: BoxDecoration(
            color: Colors.black, borderRadius: BorderRadius.circular(5.0)),
        child: Column(
          children: <Widget>[
            Container(
              height: 60.0,
              width: size.width * 0.8,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(
                      'https://disease.sh/assets/img/flags/af.png'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            // const Padding(padding: EdgeInsets.only(top:5.0),),
            const SizedBox(
              height: 5.0,
            ),
            Text('$userUid',
                style: TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                    color: Color(textGrayColor))),
            Expanded(child: ListView.builder(itemBuilder: (context, index) {
              return Container(
                child: Row(
                  children: <Widget>[
                    Expanded(
                        child: Text('${detailKeys[index]}',
                            style: TextStyle(color: Color(textGrayColor)))),
                    Text('${details[detailKeys[index]]}',
                        style: TextStyle(color: Color(textGrayColor))),
                  ],
                ),
              );
            }))
          ],
        ),
      ),
    );
  }
}
