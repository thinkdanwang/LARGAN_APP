import 'package:bloc_pattern/bloc_pattern.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:largan/pages/home_page.dart';

import '../bloc/post_bloc.dart';
import '../bloc/post_provider.dart';
import '../http/core/hi_net.dart';
import '../http/request/test_request.dart';
import '../screens/authenticate/login_bloc.dart';
import '../services/auth.dart';

// 主頁面
class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  late LoginBloc _loginBloc;
  PostBloc? _postBloc;
  Map modulesData = {};
  final Dio dio = Dio();

  //設置currentIndex來控制換頁
  int currentIndex = 0;

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    _loginBloc = BlocProvider.getBloc<LoginBloc>();
    _postBloc = PostProvider.of(context);
  }

  @override
  Widget build(BuildContext context) {
    LoginBloc loginBloc = BlocProvider.getBloc<LoginBloc>();
    final AuthService _auth = AuthService();
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          titleSpacing: 0.0,
          backgroundColor: const Color.fromRGBO(0, 49, 83, 1),
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.email),
              onPressed: () {},
            )
          ],
        ),
        body: const HomePage(),
        drawer: Drawer(
          child: ListView(padding: EdgeInsets.zero, children: <Widget>[
            const UserAccountsDrawerHeader(
              decoration: BoxDecoration(
                color: Color.fromRGBO(0, 49, 83, 0.8),
              ),
              accountName: Text("Thinkdan Wang"),
              accountEmail: Text("thinkdan715@gmail.com"),
              currentAccountPicture: CircleAvatar(
                backgroundImage: AssetImage("assets/images/25.jpg"),
              ),
            ),
            ListTile(
              title: const Text("個人基本資料"),
              trailing: const Icon(Icons.person),
              onTap: () {
                // loginBloc.currentPage = 1;
                // test();
                test();
              },
            ),
            ListTile(
              title: const Text("最新消息管理"),
              trailing: const Icon(Icons.add_a_photo_outlined),
              onTap: () {
                Navigator.pushReplacementNamed(context, "/login");
              },
            ),
            ListTile(
                title: const Text("sign out"),
                trailing: const Icon(Icons.logout_rounded),
                // onTap: () {
                //   loginBloc.currentPage = 0;
                //   // Navigator.pushReplacementNamed(context, "/login");
                // },
                onTap: () async {
                  await showDialog(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => AlertDialog(
                      content:
                          const Text("Are you sure to exit current account."),
                      actions: <Widget>[
                        ElevatedButton(
                          child: const Text("Cancel"),
                          onPressed: () => Navigator.pop(context),
                        ),
                        ElevatedButton(
                          child: const Text("OK"),
                          onPressed: () async {
                            loginBloc.currentPage = 0;
                            Navigator.pop(context);
                            await _auth.signOut();
                          },
                        ),
                      ],
                    ),
                  );
                }),
          ]),
        ),
        bottomNavigationBar: CupertinoTabBar(
            currentIndex: currentIndex, //顯示pages內該位置的Widget
            onTap: (index) {
              setState(() {
                currentIndex = index; //記得setState
              });
            },
            backgroundColor: const Color.fromRGBO(0, 49, 83, 1),
            activeColor: Colors.white, //選中時的顏色
            inactiveColor: Colors.grey, //未選中的顏色
            // selectedFontSize: 18,
            // unselectedFontSize: 24,
            iconSize: 30.0,
            items: const [
              //這邊放入數個的BottomNavigationBarItem
              BottomNavigationBarItem(
                icon: Icon(Icons.home),
                label: '首頁',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.new_label),
                label: '消息',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.question_answer),
                label: '問卷',
              ),
            ]),
      ),
    );
  }

  Future<void> test() async {
    TestRequest request = TestRequest();
    request.add("add", "ddd");
    request.addHeader("add", "ddd");
    var result = await HiNet.getInstance()?.fire(request);
    print(result);
  }
}
