import 'package:flutter/material.dart';

class LoginUserBinder extends InheritedWidget {

  final Stream value;

  const LoginUserBinder(this.value, {
    super.key,
    required Widget child,
  }) : super(child: child);

  static LoginUserBinder of(BuildContext context) {
    final LoginUserBinder? result = context.dependOnInheritedWidgetOfExactType<LoginUserBinder>();
    assert(result != null, 'No LoginUserBinder found in context');
    return result!;
  }

  @override
  bool updateShouldNotify(LoginUserBinder old) {
    return true;
  }
}
