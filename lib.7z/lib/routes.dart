class MyAppRoutes {
  static const root = "/";
  static const login = "/login";
  static const home = "/home";
  static const userInfo = "/home";
}